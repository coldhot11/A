//simulation of Banker's algorithm for deadlock avidance
//Input is static
//Set A Q.2
#define true 1
#define false 0

#include <ctype.h>
#include <stdio.h>

int avail[]={3,3,2}, work[10];
int max[][3]={{7,5,3},{3,2,2},{9,0,2},{2,2,2},{4,3,3}};
int alloc[][3]={{0,1,0},{2,0,0},{3,0,2},{2,1,1},{0,0,2}};
int need[5][3],finish[5];
int safeseq[5],ssi=-1;
int m=3,n=5,i,j;

void print_alloc_state();
void print_safess();
int safe_state();
int need_lte_work(int);


//void get_alloc_request();
void main()
{ char ch;
  int p;
  print_alloc_state();  //get avail,max,alloc and find need

  if (safe_state())
   { printf("\nSystem is in safe sate...");
     print_safess();
   }
  else
   printf("\nSystem is not in safe state...");
  
}//main

void print_alloc_state()
{   printf("\nTotal number of resource types : %d",m);
    printf("\nTotal number of processes:%d",n);
     printf("\n\nAvail instances of each resource type:\n");
	for (j=0; j<m; j++)
	{ printf("%d\t",avail[j]);
	}
	printf("\n\nmaximum demand by each process\n");
	for (i=0; i<n; i++)
	{ printf("Process %d: ",i);
	  for (j=0;j<m; j++) printf("%d\t",max[i][j]);
	  printf("\n");
	}
       
       	printf("\n\n allocation by each process\n");
	for (i=0; i<n; i++)
	{ printf("Process %d: ",i);
	  for (j=0;j<m; j++) printf("%d\t",alloc[i][j]);
	  printf("\n");
	}
	
	//calcu need
	printf("\n\nNeed by each process\n");
	for (i=0; i<n; i++)
	{ printf("Process %d: ",i);
	  for (j=0;j<m; j++)
	  { need[i][j]=max[i][j]-alloc[i][j];
	    printf("%4d",need[i][j]);
	  }
	  printf("\n");
	}
       
}//print_alloc_state

int safe_state()
{   int found;
  //Step1: let work=avail and finish[i]=false for all i
   for (j=0; j<m; j++) work[j]=avail[j];
   for (i=0; i<n; i++) finish[i]=false;

  //Step2: find an i such that finish[i]=false and need[i]<=work
  printf("\n\nCheck of safe state..");
 do
 {
  found=false;
  for (i=0; i<n; i++)
  {
   if (finish[i]==false && need_lte_work(i))
	{ //Step3
	  printf("\nSelected Process %d",i);
	  finish[i]=true; //set finish[i]=true
	  for (j=0; j<m; j++) //set work=work+alloc
	    work[j]=work[j]+alloc[i][j];
	  safeseq[++ssi]=i;
	  found=true;  break;
	}
   }

   if (found==false)  //Step4: no such  process  exist
   {  for (i=0; i<n; i++)
	 if (finish[i]==false) return(false); //unsafe state

      return(true);
   }
 } while(1);
}//safe_State

int need_lte_work(int i)
{  for (j=0; j<m; j++)
   { if (need[i][j]>work[j])
       return(false);
   }
   return(true);
}//need_lte_work

void print_safess()
{
  printf("\nSafe Sequence : ");
  for (i=0; i<=ssi; i++)
	printf("%4d",safeseq[i]);
}
