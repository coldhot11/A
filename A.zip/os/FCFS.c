//Simulate or Implement FCFS Disk Scheduling Algorithm

#include <stdio.h>
#include <stdlib.h>

void main()
{
  int request[]={55, 58, 39, 18, 90, 160, 150, 38, 184};
  int i,req,n=9;//No. of requests 9
  int totblocks=200;
  int hpos=50;//Assume current head position
  int thmov=0; //total head movements
  
  printf("Head moved to track %d\n",hpos);
  for (i=0;i<n;i++)
  {
    req=request[i]; //Get next request
    thmov+=abs(req-hpos);
    hpos=req;
    printf("Head moved to track %d\n",hpos);
  }  
  printf("Total head movements=%d\n",thmov);
}

