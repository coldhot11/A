//Simulate or Implement C-LOOK Disk Scheduling Algorithm

#include <stdio.h>
#include <stdlib.h>

void main()
{ int request[]={56, 59, 40, 19, 91, 161, 151, 39, 185}; 
  int i,j,temp,req,stno,stdist,n=9;
  int hpos=48;
  int firstt=0,lastt=199; 
  int thmov=0; 
  
  
  for(i=0;i<n;i++)
    for(j=i+1;j<n;j++)
     if(request[i]>request[j])
      { temp=request[i];
        request[i]=request[j];
        request[j]=temp;
      }
   
  j=0;
  for(j=0;request[j]<hpos;j++);
  
  thmov+=abs(request[j]-hpos);
  printf("current head position=%d\n",hpos);  
  
 for(i=j;i<n;i++)
 { thmov+=abs(request[i]-hpos); 
   hpos=request[i];
   printf("current head position=%d\n",hpos); 
 }
  
 for(i=0;i<j;i++)
 { thmov+=abs(request[i]-hpos); 
   hpos=request[i];
   printf("current head position=%d\n",hpos); 
 }

  printf("Total head movements=%d\n",thmov);
}

