//Simulate or Implement SSTF Disk Scheduling Algorithm

#include <stdio.h>
#include <stdlib.h>

void main()
{ int request[]={186, 89, 44, 70, 102, 22, 51, 124};
  int i,j,req,stno,stdist,n=8;//Total requests 8
  int hpos=60;//Assume current head position
  int thmov=0; //total head movements
  
  printf("current head position=%d\n",hpos);
  while(n!=0)
 { 
  //Find shortest seek time track
  j=0; //assume first request is shortest
  stdist=abs(request[j]-hpos); 
  for(int i=1;i<n;i++)
   { if (abs(request[i]-hpos)<=stdist)
      { j=i; //Get next shortest
        stdist=abs(request[i]-hpos);
      }
   }
   hpos=request[j]; //Move head to jth pos
   thmov+=stdist;//Find total head movements
   printf("current head position=%d\n",hpos);
   
   for (i=j;i<n-1;i++)  //Remove jth request
       request[i]=request[i+1];
   
   n--;
  }
  printf("Total head movements=%d\n",thmov);
}

