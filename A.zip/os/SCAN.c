//Simulate or Implement SCAN Disk Scheduling Algorithm

#include <stdio.h>
#include <stdlib.h>

void main()
{ int request[]={98,183,41,122,14,124,65,67}; //14,41,65,67,98,122,124,183
  int i,j,temp,req,stno,stdist,n=8;
  int hpos=53;//Assume current head position
  int firstt=0,lastt=199; //Assume First Track 0 and Last track 199
  int thmov=0; //total head movements
  
  //Sort all track requests in ascending
  for(i=0;i<n;i++)
    for(j=i+1;j<n;j++)
     if(request[i]>request[j])
      { temp=request[i];
        request[i]=request[j];
        request[j]=temp;
      }
   
  //Set head position at request next hpos
  j=0;
  for(j=0;request[j]<hpos;j++);
  
  thmov+=abs(request[j]-hpos);
  printf("current head position=%d\n",hpos);  
   //Assume head move toward right direction
 //Scan and Service request from hpos to last track
 for(i=j;i<n;i++)
 { thmov+=abs(request[i]-hpos); 
   hpos=request[i];
   printf("current head position=%d\n",hpos); 
 }
  
 hpos=lastt;// set head position at last track
 thmov+=abs(hpos-request[i-1]); 
 printf("current head position=%d\n",hpos);  
 
 //Scan and Service request from last track to first track
 for(i=j-1;i>0;i--)
 { 
   thmov+=abs(request[i]-hpos);
   hpos=request[i];
   printf("current head position=%d\n",hpos); 
 }
  
  printf("Total head movements=%d\n",thmov);
}

